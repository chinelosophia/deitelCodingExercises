package chapter4;

public class Prime2 {
  public static void main(String[] args ){
int number = 100;
System.out.println("Enter a number");
System.out.println("100 is a prime number");
  }
}
