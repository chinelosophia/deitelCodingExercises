import java.util.Scanner;

public class Example {
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        System.out.println("abeg wetin be ya age");
        int age = scanner.nextInt();

        switch(age){
            case 20:
                System.out.println("getat!!");

                case 40:
                System.out.println("you try small!!");



        }

    }
}
